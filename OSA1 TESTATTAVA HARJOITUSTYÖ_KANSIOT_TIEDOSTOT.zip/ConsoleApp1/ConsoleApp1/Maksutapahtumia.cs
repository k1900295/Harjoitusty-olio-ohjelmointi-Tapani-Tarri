﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    //Tämän luokan perintä luokassa Rivit tiedostossa Tapahtumarivit.cs
    public abstract class Maksutapahtumia
    {
        public abstract int Maksut();        
    }
}